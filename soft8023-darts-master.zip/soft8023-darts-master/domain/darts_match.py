class DartsMatch:

    def __init__(self, type, player1, player2):
        self.type = type
        self.player1 = player1
        self.player2 = player2